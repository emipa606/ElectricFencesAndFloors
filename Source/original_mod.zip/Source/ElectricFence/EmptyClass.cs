﻿using System;

namespace ElectricFence
{
	public class EmptyClass
	{
		public EmptyClass ()
		{
		}
	}
}

